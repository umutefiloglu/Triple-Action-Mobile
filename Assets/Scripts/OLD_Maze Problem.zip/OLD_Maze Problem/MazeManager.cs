using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MazeManager : MonoBehaviour
{
    /// <summary>
    /// Number of vertices representing each maze cells
    /// </summary>
    [SerializeField] private int eachCellDistance = 2;
    /// <summary>
    /// Horizontal number of cells
    /// </summary>
    [ReadOnly] [SerializeField] private int horzCells = 0;
    /// <summary>
    /// Number of vertices representing each maze cells
    /// </summary>
    [ReadOnly] [SerializeField] private int numberOfVertices = 0;
    /// <summary>
    /// Number of edges representing each connection between vertices
    /// </summary>
    [ReadOnly] [SerializeField] private int numberOfEdges = 0;
    /// <summary>
    /// Number of edges representing each connection between vertices
    /// </summary>
    [ReadOnly] [SerializeField] private int mstCost = 0;
    /// <summary>
    /// Vertices
    /// </summary>
    [ReadOnly] private List<int> vertices;
    /// <summary>
    /// Starting point of edge i
    /// </summary>
    [ReadOnly] private List<int> edgeSource;
    /// <summary>
    /// Ending point of edge i
    /// </summary>
    [ReadOnly] private List<int> edgeDestination;
    /// <summary>
    /// Ending point of edge i
    /// </summary>
    [ReadOnly] private List<int> weight;
    /// <summary>
    /// Ending point of edge i
    /// </summary>
    [ReadOnly] private List<MazeCell> mazeCells;

    /// <summary>
    /// Finds number of horizontal cells and stores it in horzCells variable
    /// </summary>
    private void FindNumberOfHorzCells()
    {
        // Find number of horzCells
        for (int i = 0; i < transform.childCount; i++)
        {
            horzCells++;
            if (transform.GetChild(i).transform.position.z !=
                transform.GetChild(i + 1).transform.position.z)
                break;
        }
    }
    /// <summary>
    /// Finds number of vertices and stores it in numberOfVertices variable
    /// </summary>
    private void FindNumberOfVertices()
    {
        vertices = new List<int>();
        // Find number of Vertices
        for (int i = 0; i < transform.childCount; i++)
        {
            if (transform.GetChild(i).GetChild(0).gameObject.activeInHierarchy == false)
            {
                numberOfVertices++;
                vertices.Add(i);
            }
        }
    }
    /// <summary>
    /// Finds connections between vertices; hence populates
    /// edgeSource[] && edgeDestination[] arrays
    /// </summary>
    private void FindEdges()
    {
        List<int> _tempSource = new List<int>();
        List<int> _tempDest = new List<int>();
        List<int> _tempVertices = new List<int>();

        // Maze Cells are connected with edges
        // Each cell center is 2 units apart from each other
        // Maze Cells are arranged as child of this objects like:
        //  [BIRD'S-EYE VIEW]
        //
        //------------------> X+ (Cell Width)
        //                  |
        //  ->->->->        |
        // |                |
        // v                |
        //  ->->->->        |
        // |                |
        // v                |
        //  ->...           V Z+ (Cell Height)
        for (int i = 0; i < transform.childCount - 1; i++)
        {
            // Horizontal Edge Check: [i]-[i+1]
            // If both cells are on same row...
            if (transform.GetChild(i).transform.position.z ==
                transform.GetChild(i + 1).transform.position.z)
            {
                // If both cells have no obstacle...
                if (!transform.GetChild(i).transform.GetChild(0).gameObject.activeInHierarchy &&
                    !transform.GetChild(i + 1).transform.GetChild(0).gameObject.activeInHierarchy)
                {
                    // Add edge and vertex
                    numberOfEdges++;
                    //Debug.Log("Edge: " + i + " - " + (i + 1));
                    _tempSource.Add(i);
                    _tempDest.Add(i + 1);
                }
            }

            // Vertical Edge Check:
            // [i].x                    &&             [i+1].x
            //  |                                        |
            // [i+horzCells].x                    [i+1+horzCells].x


            // Checking boundary for i
            if (i + horzCells < transform.childCount)
            {
                // If both cells are on same Column...
                if (transform.GetChild(i).transform.position.x ==
                    transform.GetChild(i + horzCells).transform.position.x)
                {
                    // If both cells have no obstacle...
                    if (!transform.GetChild(i).transform.GetChild(0).gameObject.activeInHierarchy &&
                        !transform.GetChild(i + horzCells).transform.GetChild(0).gameObject.activeInHierarchy)
                    {
                        // Add edge and vertex
                        numberOfEdges++;
                        //Debug.Log("Edge: " + i + " - " + (i + horzCells));
                        _tempSource.Add(i);
                        _tempDest.Add(i + horzCells);
                    }
                }
            }
            // Checking boundary for i + 1
            if (i + 1 + horzCells < transform.childCount)
            {
                // If both cells are on same Column...
                if (transform.GetChild(i).transform.position.x ==
                    transform.GetChild(i + 1 + horzCells).transform.position.x)
                {
                    // If both cells have no obstacle...
                    if (!transform.GetChild(i + 1).transform.GetChild(0).gameObject.activeInHierarchy &&
                        !transform.GetChild(i + 1 + horzCells).transform.GetChild(0).gameObject.activeInHierarchy)
                    {
                        // Add edge and vertex
                        numberOfEdges++;
                        //Debug.Log("Edge: " + i + " - " + (i + 1 + horzCells));
                        _tempSource.Add(i);
                        _tempDest.Add(i + 1 + horzCells);
                    }
                }
            }
        }


        for (int i = 0; i < vertices.Count - 1; i++)
        {
            if (vertices[i + 1] - vertices[i] > 1)
            {
                int _temp = vertices[i + 1];
                vertices[i + 1] = vertices[i] + 1;

                // Edge Source list
                int index = _tempSource.FindIndex(s => s == _temp);
                while (index != -1)
                {
                    _tempSource[index] = vertices[i] + 1;
                    index = _tempSource.FindIndex(s => s == _temp);
                }

                // Edge Destination list
                index = _tempDest.FindIndex(s => s == _temp);
                while (index != -1)
                {
                    _tempDest[index] = vertices[i] + 1;
                    index = _tempDest.FindIndex(s => s == _temp);
                }
            }
        }

        // Initialize required variables for graph
        edgeSource = _tempSource;
        edgeDestination = _tempDest;
    }
    /// <summary>
    /// Initializes mazeCells array of MazeCell struct
    /// </summary>
    private void InitMazeCellsStruct()
    {
        mazeCells = new List<MazeCell>();

        int _tempInd = 0;
        for (int i = 0; i < transform.childCount; i++)
        {
            if (transform.GetChild(i).GetChild(0).gameObject.activeInHierarchy == false)
            {
                mazeCells.Add(new MazeCell(_tempInd, new Vector2(transform.GetChild(i).localPosition.x, transform.GetChild(i).localPosition.z)));
                _tempInd++;
            }
        }

        //// Populate mazeCells' neighbor list
        //for (int i = 0; i < mazeCells.Count; i++)
        //{
        //    List<Vector2> pos = new List<Vector2>();
        //    List<int> inds = new List<int>();
        //    inds = edgeSource.FindAll(s => s == mazeCells[i].vertInd);

        //    foreach (var ind in inds)
        //    {
        //        mazeCells[i].neighbors.Add(new MazeCell(edgeDestination[ind]));
        //    }
        //}
    }

    private void Awake()
    {
        FindNumberOfHorzCells();
        FindNumberOfVertices();
        FindEdges();
        InitMazeCellsStruct();

        var gaController = GetComponent<GAController>();
        gaController.positions = new Vector2[mazeCells.Count];
        for (int i = 0; i < mazeCells.Count; i++)
        {
            gaController.positions[i] = mazeCells[i].vertPos;
            gaController.from.Add(edgeSource[i]);
            gaController.to.Add(edgeDestination[i]);
        }

       

        //Debug.Log("final cost: " + mstCost);
    }

    private void Update()
    {

    }

    /// <summary>
    /// Calculates and returns minimum number of balls required to complete maze
    /// </summary>
    public static void CalcMinReqBalls()
    {
        // CanvasManager.Instance.MinReqBalls = calcu
    }


    
}
