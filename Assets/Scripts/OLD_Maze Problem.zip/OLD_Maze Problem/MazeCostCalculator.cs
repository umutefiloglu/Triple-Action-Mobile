using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MazeCostCalculator
{

    // Function to find the minimum weight Hamiltonian Cycle
    static int tsp(int[,] graph, bool[] v, int currPos,
            int n, int count, int cost, int ans)
    {

        // If last node is reached and it has a link
        // to the starting node i.e the source then
        // keep the minimum value out of the total cost
        // of traversal and "ans"
        // Finally return to check for more possible values
        if (count == n && graph[currPos, 0] > 0)
        {
            ans = Math.Min(ans, cost + graph[currPos, 0]);
            return ans;
        }

        // BACKTRACKING STEP
        // Loop to traverse the adjacency list
        // of currPos node and increasing the count
        // by 1 and cost by graph[currPos,i] value
        for (int i = 0; i < n; i++)
        {
            if (v[i] == false && graph[currPos, i] > 0)
            {

                // Mark as visited
                v[i] = true;
                ans = tsp(graph, v, i, n, count + 1,
                    cost + graph[currPos, i], ans);

                // Mark ith node as unvisited
                v[i] = false;
            }
        }
        return ans;
    }

    // Driver code
    public static int TSP_Cost(int nodeNum, int[,]g)
    {
        // n is the number of nodes i.e. V
        int n = nodeNum;

        int[,] graph = g;

        // Boolean array to check if a node
        // has been visited or not
        bool[] v = new bool[n];

        // Mark 0th node as visited
        v[0] = true;
        int ans = int.MaxValue;

        // Find the minimum weight Hamiltonian Cycle
        ans = tsp(graph, v, 0, n, 1, 0, ans);

        // ans is the minimum weight Hamiltonian Cycle
        return ans;

    }
}

// This code is contributed by mits and modified by Umut Efiloglu
// https://www.geeksforgeeks.org/travelling-salesman-problem-implementation-using-backtracking/
