using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// A class to represent a graph edge
public class Edge : IComparable<Edge>
{
    public int src, dest, weight;

    public Edge()
    {

    }

    // Comparator function used for sorting edges
    // based on their weight
    public int CompareTo(Edge compareEdge)
    {
        return this.weight - compareEdge.weight;
    }
}
// A class to represent a subset for union-find
class subset
{
    public int parent, rank;
};
class Graph
{
    int V, E; // V-> no. of vertices & E->no.of edges
    public Edge[] edge; // collection of all edges

    // Creates a graph with V vertices and E edges
    public Graph(int v, int e)
    {
        V = v;
        E = e;
        edge = new Edge[E];
        for (int i = 0; i < e; ++i)
            edge[i] = new Edge();
    }

    // A utility function to find set of an element i
    // (uses path compression technique)
    int find(subset[] subsets, int i)
    {
        // find root and make root as parent of i (path compression)
        if (subsets[i].parent != i)
            subsets[i].parent = find(subsets, subsets[i].parent);
        return subsets[i].parent;
    }

    // A function that does union of
    // two sets of x and y (uses union by rank)
    void Union(subset[] subsets, int x, int y)
    {
        int xroot = find(subsets, x);
        int yroot = find(subsets, y);

        // Attach smaller rank tree under root of
        // high rank tree (Union by Rank)
        if (subsets[xroot].rank < subsets[yroot].rank)
            subsets[xroot].parent = yroot;

        else if (subsets[xroot].rank > subsets[yroot].rank)
            subsets[yroot].parent = xroot;

        // If ranks are same, then make one as root
        // and increment its rank by one
        else
        {
            subsets[yroot].parent = xroot;
            subsets[xroot].rank++;
        }
    }

    // The main function to construct MST using Kruskal's algorithm
    public Edge[] KruskalMST()
    {
        // This will store the resultant MST
        Edge[] result = new Edge[V];

        int e = 0; // An index variable, used for result[]
        int i = 0; // An index variable, used for sorted edges

        for (i = 0; i < V; ++i)
            result[i] = new Edge();


        // Step 1: Sort all the edges in non-decreasing
        // order of their weight. If we are not allowed
        // to change the given graph, we can create
        // a copy of array of edges
        Array.Sort(edge);

        // Allocate memory for creating V subsets
        subset[] subsets = new subset[V];

        for (i = 0; i < V; ++i)
            subsets[i] = new subset();

        // Create V subsets with single elements
        for (int v = 0; v < V; ++v)
        {
            subsets[v].parent = v;
            subsets[v].rank = 0;
        }

        i = 0; // Index used to pick next edge

        // Number of edges to be taken is equal to V-1
        while (e < V - 1)
        {
            // Step 2: Pick the smallest edge. And increment
            // the index for next iteration
            Edge next_edge = new Edge();
            next_edge = edge[i++];
            int x = find(subsets, next_edge.src);
            int y = find(subsets, next_edge.dest);

            // If including this edge does't cause cycle,
            // include it in result and increment the index
            // of result for next edge
            if (x != y)
            {
                result[e++] = next_edge;
                Union(subsets, x, y);
            }
            // Else discard the next_edge
        }

        // print the contents of result[] to display
        // the built MST
        Debug.Log("Following are the edges in "
                          + "the constructed MST");

        int minimumCost = 0;
        for (i = 0; i < e; ++i)
        {
            Debug.Log(result[i].src + " -- "
                              + result[i].dest
                              + " == " + result[i].weight);
            minimumCost += result[i].weight;
        }

        Debug.Log("Minimum Cost Spanning Tree"
                          + minimumCost);
        return result;
    }
}

public class MSTCalculator
{
    public static int CalculateMST(int vertnum, int edgenum, int[]src, int[]dest)
    {
        Graph graph = new Graph(vertnum, edgenum);

        for (int i = 0; i < edgenum; i++)
        {
            graph.edge[i].src = src[i];
            graph.edge[i].dest = dest[i];
            graph.edge[i].weight = 1;
            //Debug.Log("Edge: " + src[i] + " - " + dest[i]);
        }

        // Function call
        Edge[] _tmpEdge = graph.KruskalMST();
        int[] _tmpSrc = new int[_tmpEdge.Length];
        int[] _tmpDest = new int[_tmpEdge.Length];
        int[] _tmpWt = new int[_tmpEdge.Length];

        for (int i = 0; i < _tmpEdge.Length; i++)
        {
            _tmpSrc[i] = _tmpEdge[i].src;
            _tmpDest[i] = _tmpEdge[i].dest;
            _tmpWt[i] = _tmpEdge[i].weight;
        }

        int[] _tmpW2 = new int[src.Length];
        for (int i = 0; i < _tmpW2.Length; i++)
        {
            _tmpW2[i] = 1;
        }

        // Populate MazeCostCalculator
        //return MazeCostCalculator.CalculateCost(vertnum, _tmpSrc, _tmpDest, _tmpWt);
        return 0;
    }
}

// This code is modified by Umut Efiloglu
// and contributed by Aakash Hasija
// https://www.geeksforgeeks.org/kruskals-minimum-spanning-tree-algorithm-greedy-algo-2/amp/
