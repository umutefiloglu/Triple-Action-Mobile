using UnityEngine;

public class TspCity
{
    public int index { get; set; }
    public Vector2 Position { get; set; }
}